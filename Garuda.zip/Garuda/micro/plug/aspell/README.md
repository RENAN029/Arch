# Aspell plugin for Micro

This is a spellchecking plugin for [Micro](https://micro-editor.github.io/) editor.
For help see [the help file](help/aspell.md).
